// AVM1 DoInitAction (Sprite ID: 791) — Tag #208 @ 0x478B7
function onFrameTimeline():Void {
  if (898) { /* branch +33 */ }
  \u0001 = \u0001 - 248;
  if (721) { /* branch +33 */ }
  \u0001 = \u0001 - 183;
  if (977) { /* branch +34 */ }
  \u0001 = \u0001 - 270;
  if (268) { /* branch +33 */ }
  \u0001 = \u0001 + 232;
  if (101) { /* branch +33 */ }
  \u0001 = \u0001 + 255;
  if (650) { /* branch +61 */ }
  \u0001 = \u0001 - 382;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 232;
  if (500) { /* branch +28 */ }
  \u0001 = \u0001 + 496;
  if (967) { /* branch +678 */ }
  \u0001 = \u0001 - 866;
  if (821) { /* branch +61 */ }
  \u0001 = \u0001 + 146;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 866;
  if (841) { /* branch +59 */ }
  \u0001 = \u0001 + 155;
  if (996) { /* branch +33 */ }
  \u0001 = \u0001 - 969;
  if (731) { /* branch +42 */ }
  \u0001 = \u0001 - 282;
  if (356) { /* branch +29 */ }
  \u0001 = \u0001 - 356;
}
