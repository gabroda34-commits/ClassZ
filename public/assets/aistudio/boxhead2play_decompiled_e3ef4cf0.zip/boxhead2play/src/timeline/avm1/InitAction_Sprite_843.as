// AVM1 DoInitAction (Sprite ID: 843) — Tag #416 @ 0x76DE1
function onFrameTimeline():Void {
  if (231) { /* branch +33 */ }
  \u0001 = \u0001 + 694;
  if (912) { /* branch +33 */ }
  \u0001 = \u0001 - 827;
  if (609) { /* branch +48 */ }
  \u0001 = \u0001 - 420;
  if (488) { /* branch +29 */ }
  \u0001 = \u0001 - 315;
  if (925) { /* branch +61 */ }
  \u0001 = \u0001 - 13;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 827;
  if (85) { /* branch +28 */ }
  \u0001 = \u0001 + 104;
  if (189) { /* branch +39 */ }
  \u0001 = \u0001 + 299;
  if (173) { /* branch +34 */ }
  \u0001 = \u0001 + 659;
  if (832) { /* branch +29 */ }
  \u0001 = \u0001 + 96;
  if (928) { /* branch +29 */ }
  \u0001 = \u0001 - 92;
  if (836) { /* branch +61 */ }
  \u0001 = \u0001 + 6;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 761;
  if (842) { /* branch +1893 */ }
  \u0001 = \u0001 - 761;
  if (81) { /* branch +33 */ }
  \u0001 = \u0001 + 890;
  if (971) { /* branch +29 */ }
  \u0001 = \u0001 - 971;
}
