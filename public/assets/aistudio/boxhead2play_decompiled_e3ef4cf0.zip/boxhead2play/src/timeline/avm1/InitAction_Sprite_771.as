// AVM1 DoInitAction (Sprite ID: 771) — Tag #128 @ 0x2CADE
function onFrameTimeline():Void {
  if (597) { /* branch +33 */ }
  \u0001 = \u0001 - 505;
  if (92) { /* branch +61 */ }
  \u0001 = \u0001 + 412;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 311;
  if (823) { /* branch +993 */ }
  \u0001 = \u0001 - 428;
  if (810) { /* branch +52 */ }
  \u0001 = \u0001 - 787;
  if (23) { /* branch +39 */ }
  \u0001 = \u0001 + 370;
  if (840) { /* branch +29 */ }
  \u0001 = \u0001 + 55;
  if (433) { /* branch +34 */ }
  \u0001 = \u0001 + 547;
  if (393) { /* branch +29 */ }
  \u0001 = \u0001 + 40;
  if (193) { /* branch +28 */ }
  \u0001 = \u0001 - 170;
  if (980) { /* branch +29 */ }
  \u0001 = \u0001 - 140;
  if (895) { /* branch +61 */ }
  \u0001 = \u0001 - 72;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 428;
  if (504) { /* branch +33 */ }
  \u0001 = \u0001 - 311;
  if (395) { /* branch +33 */ }
  \u0001 = \u0001 + 31;
  if (426) { /* branch +29 */ }
  \u0001 = \u0001 - 426;
}
