// AVM1 DoInitAction (Sprite ID: 785) — Tag #184 @ 0x42861
function onFrameTimeline():Void {
  if (780) { /* branch +33 */ }
  \u0001 = \u0001 - 3;
  if (461) { /* branch +29 */ }
  \u0001 = \u0001 + 428;
  if (996) { /* branch +28 */ }
  \u0001 = \u0001 - 228;
  if (714) { /* branch +61 */ }
  \u0001 = \u0001 + 148;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 63;
  if (719) { /* branch +51 */ }
  \u0001 = \u0001 + 49;
  if (889) { /* branch +29 */ }
  \u0001 = \u0001 - 175;
  if (704) { /* branch +33 */ }
  \u0001 = \u0001 + 292;
  if (768) { /* branch +39 */ }
  \u0001 = \u0001 - 765;
  if (862) { /* branch +1470 */ }
  \u0001 = \u0001 + 63;
  if (777) { /* branch +61 */ }
  \u0001 = \u0001 - 73;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 292;
  if (480) { /* branch +34 */ }
  \u0001 = \u0001 - 19;
  if (3) { /* branch +29 */ }
  \u0001 = \u0001 + 477;
  if (925) { /* branch +33 */ }
  \u0001 = \u0001 - 735;
  if (190) { /* branch +29 */ }
  \u0001 = \u0001 - 190;
}
