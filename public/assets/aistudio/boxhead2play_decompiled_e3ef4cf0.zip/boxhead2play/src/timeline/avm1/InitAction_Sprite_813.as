// AVM1 DoInitAction (Sprite ID: 813) — Tag #296 @ 0x58CA8
function onFrameTimeline():Void {
  if (714) { /* branch +33 */ }
  \u0001 = \u0001 - 709;
  if (486) { /* branch +29 */ }
  \u0001 = \u0001 - 320;
  if (222) { /* branch +28 */ }
  \u0001 = \u0001 + 404;
  if (109) { /* branch +186 */ }
  \u0001 = \u0001 + 815;
  if (626) { /* branch +39 */ }
  \u0001 = \u0001 - 374;
  if (924) { /* branch +33 */ }
  \u0001 = \u0001 - 355;
  if (166) { /* branch +61 */ }
  \u0001 = \u0001 - 57;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 815;
  if (345) { /* branch +34 */ }
  \u0001 = \u0001 + 170;
  if (709) { /* branch +33 */ }
  \u0001 = \u0001 - 487;
  if (431) { /* branch +64 */ }
  \u0001 = \u0001 + 195;
  if (515) { /* branch +29 */ }
  \u0001 = \u0001 - 29;
  if (569) { /* branch +29 */ }
  \u0001 = \u0001 - 569;
}
