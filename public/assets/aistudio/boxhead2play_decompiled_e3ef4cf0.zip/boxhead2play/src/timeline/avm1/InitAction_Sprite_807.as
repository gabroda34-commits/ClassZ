// AVM1 DoInitAction (Sprite ID: 807) — Tag #272 @ 0x53573
function onFrameTimeline():Void {
  if (490) { /* branch +33 */ }
  \u0001 = \u0001 + 254;
  if (737) { /* branch +28 */ }
  \u0001 = \u0001 + 43;
  if (95) { /* branch +29 */ }
  \u0001 = \u0001 - 37;
  if (94) { /* branch +29 */ }
  \u0001 = \u0001 + 1;
  if (872) { /* branch +34 */ }
  \u0001 = \u0001 - 778;
  if (58) { /* branch +61 */ }
  \u0001 = \u0001 + 381;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 137;
  if (439) { /* branch +167 */ }
  \u0001 = \u0001 - 137;
  if (341) { /* branch +29 */ }
  \u0001 = \u0001 + 531;
  if (780) { /* branch +39 */ }
  \u0001 = \u0001 - 439;
  if (302) { /* branch +33 */ }
  \u0001 = \u0001 - 4;
  if (823) { /* branch +33 */ }
  \u0001 = \u0001 - 86;
  if (298) { /* branch +29 */ }
  \u0001 = \u0001 - 298;
}
