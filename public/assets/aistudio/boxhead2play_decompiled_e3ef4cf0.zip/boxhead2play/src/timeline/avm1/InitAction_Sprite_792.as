// AVM1 DoInitAction (Sprite ID: 792) — Tag #212 @ 0x48347
function onFrameTimeline():Void {
  if (793) { /* branch +33 */ }
  \u0001 = \u0001 - 114;
  if (583) { /* branch +29 */ }
  \u0001 = \u0001 + 185;
  if (687) { /* branch +28 */ }
  \u0001 = \u0001 - 549;
  if (768) { /* branch +34 */ }
  \u0001 = \u0001 - 35;
  if (285) { /* branch +33 */ }
  \u0001 = \u0001 + 272;
  if (733) { /* branch +29 */ }
  \u0001 = \u0001 - 575;
  if (158) { /* branch +29 */ }
  \u0001 = \u0001 + 423;
  if (210) { /* branch +33 */ }
  \u0001 = \u0001 + 477;
  if (679) { /* branch +61 */ }
  \u0001 = \u0001 - 469;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 477;
  if (168) { /* branch +48 */ }
  \u0001 = \u0001 - 30;
  if (896) { /* branch +400 */ }
  \u0001 = \u0001 - 611;
  if (557) { /* branch +29 */ }
  \u0001 = \u0001 - 557;
}
