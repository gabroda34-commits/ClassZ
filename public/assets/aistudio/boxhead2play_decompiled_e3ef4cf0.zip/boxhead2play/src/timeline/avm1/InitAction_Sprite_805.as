// AVM1 DoInitAction (Sprite ID: 805) — Tag #264 @ 0x51BB5
function onFrameTimeline():Void {
  if (397) { /* branch +33 */ }
  \u0001 = \u0001 - 263;
  if (134) { /* branch +61 */ }
  \u0001 = \u0001 + 394;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 163;
  if (573) { /* branch +34 */ }
  \u0001 = \u0001 + 397;
  if (244) { /* branch +29 */ }
  \u0001 = \u0001 + 2;
  if (557) { /* branch +962 */ }
  \u0001 = \u0001 - 26;
  if (528) { /* branch +33 */ }
  \u0001 = \u0001 - 163;
  if (365) { /* branch +28 */ }
  \u0001 = \u0001 + 345;
  if (774) { /* branch +59 */ }
  \u0001 = \u0001 - 64;
  if (710) { /* branch +39 */ }
  \u0001 = \u0001 + 164;
  if (874) { /* branch +29 */ }
  \u0001 = \u0001 - 301;
  if (970) { /* branch +29 */ }
  \u0001 = \u0001 - 726;
  if (246) { /* branch +61 */ }
  \u0001 = \u0001 + 311;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 26;
  if (531) { /* branch +33 */ }
  \u0001 = \u0001 - 162;
  if (369) { /* branch +29 */ }
  \u0001 = \u0001 - 369;
}
