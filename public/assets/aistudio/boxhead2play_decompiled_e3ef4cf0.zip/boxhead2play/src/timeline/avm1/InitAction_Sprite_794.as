// AVM1 DoInitAction (Sprite ID: 794) — Tag #220 @ 0x49F8F
function onFrameTimeline():Void {
  if (327) { /* branch +33 */ }
  \u0001 = \u0001 + 367;
  if (675) { /* branch +61 */ }
  \u0001 = \u0001 + 293;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 722;
  if (246) { /* branch +33 */ }
  \u0001 = \u0001 - 132;
  if (694) { /* branch +61 */ }
  \u0001 = \u0001 - 332;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 11;
  if (968) { /* branch +787 */ }
  \u0001 = \u0001 - 722;
  if (954) { /* branch +29 */ }
  \u0001 = \u0001 - 272;
  if (362) { /* branch +33 */ }
  \u0001 = \u0001 - 11;
  if (197) { /* branch +39 */ }
  \u0001 = \u0001 + 757;
  if (351) { /* branch +28 */ }
  \u0001 = \u0001 - 154;
  if (304) { /* branch +58 */ }
  \u0001 = \u0001 - 107;
  if (682) { /* branch +34 */ }
  \u0001 = \u0001 + 17;
  if (699) { /* branch +29 */ }
  \u0001 = \u0001 - 436;
  if (263) { /* branch +29 */ }
  \u0001 = \u0001 + 412;
  if (114) { /* branch +29 */ }
  \u0001 = \u0001 - 114;
}
