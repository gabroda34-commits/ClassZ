// AVM1 DoInitAction (Sprite ID: 96) — Tag #1309 @ 0x1AFE12
function onFrameTimeline():Void {
  if (190) { /* branch +33 */ }
  \u0001 = \u0001 + 93;
  if (283) { /* branch +61 */ }
  \u0001 = \u0001 + 67;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 28;
  if (628) { /* branch +39 */ }
  \u0001 = \u0001 + 267;
  if (888) { /* branch +33 */ }
  \u0001 = \u0001 - 717;
  if (15) { /* branch +29 */ }
  \u0001 = \u0001 + 957;
  if (350) { /* branch +33 */ }
  \u0001 = \u0001 + 28;
  if (378) { /* branch +28 */ }
  \u0001 = \u0001 + 250;
  if (64) { /* branch +34 */ }
  \u0001 = \u0001 + 118;
  if (736) { /* branch +42 */ }
  \u0001 = \u0001 - 108;
  if (895) { /* branch +29 */ }
  \u0001 = \u0001 - 831;
  if (182) { /* branch +29 */ }
  \u0001 = \u0001 - 167;
  if (972) { /* branch +61 */ }
  \u0001 = \u0001 - 84;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 0;
  if (171) { /* branch +29 */ }
  \u0001 = \u0001 - 171;
}
