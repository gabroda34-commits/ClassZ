// AVM1 DoInitAction (Sprite ID: 765) — Tag #104 @ 0x226E8
function onFrameTimeline():Void {
  if (654) { /* branch +33 */ }
  \u0001 = \u0001 + 185;
  if (560) { /* branch +29 */ }
  \u0001 = \u0001 - 499;
  if (463) { /* branch +33 */ }
  \u0001 = \u0001 + 228;
  if (273) { /* branch +50 */ }
  \u0001 = \u0001 + 154;
  if (536) { /* branch +28 */ }
  \u0001 = \u0001 - 109;
  if (385) { /* branch +33 */ }
  \u0001 = \u0001 + 151;
  if (839) { /* branch +61 */ }
  \u0001 = \u0001 - 454;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 151;
  if (427) { /* branch +39 */ }
  \u0001 = \u0001 + 177;
  if (870) { /* branch +888 */ }
  \u0001 = \u0001 - 407;
  if (964) { /* branch +61 */ }
  \u0001 = \u0001 - 94;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 407;
  if (604) { /* branch +29 */ }
  \u0001 = \u0001 - 521;
  if (691) { /* branch +29 */ }
  \u0001 = \u0001 - 691;
}
