// AVM1 DoInitAction (Sprite ID: 784) — Tag #180 @ 0x41909
function onFrameTimeline():Void {
  if (983) { /* branch +33 */ }
  \u0001 = \u0001 - 672;
  if (311) { /* branch +61 */ }
  \u0001 = \u0001 + 115;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 339;
  if (378) { /* branch +61 */ }
  \u0001 = \u0001 - 300;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 330;
  if (249) { /* branch +29 */ }
  \u0001 = \u0001 + 129;
  if (78) { /* branch +284 */ }
  \u0001 = \u0001 + 330;
  if (426) { /* branch +33 */ }
  \u0001 = \u0001 - 339;
  if (629) { /* branch +44 */ }
  \u0001 = \u0001 + 121;
  if (408) { /* branch +33 */ }
  \u0001 = \u0001 - 246;
  if (964) { /* branch +29 */ }
  \u0001 = \u0001 - 27;
  if (87) { /* branch +28 */ }
  \u0001 = \u0001 + 663;
  if (937) { /* branch +34 */ }
  \u0001 = \u0001 + 14;
  if (162) { /* branch +29 */ }
  \u0001 = \u0001 - 162;
}
