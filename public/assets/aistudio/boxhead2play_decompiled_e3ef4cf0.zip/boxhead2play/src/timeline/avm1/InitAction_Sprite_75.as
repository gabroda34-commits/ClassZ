// AVM1 DoInitAction (Sprite ID: 75) — Tag #1295 @ 0x1ACBED
function onFrameTimeline():Void {
  if (875) { /* branch +33 */ }
  \u0001 = \u0001 - 240;
  if (635) { /* branch +61 */ }
  \u0001 = \u0001 - 45;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 218;
  if (792) { /* branch +61 */ }
  \u0001 = \u0001 - 207;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 29;
  if (585) { /* branch +33 */ }
  \u0001 = \u0001 - 29;
  if (621) { /* branch +61 */ }
  \u0001 = \u0001 + 331;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 0;
  if (312) { /* branch +33 */ }
  \u0001 = \u0001 + 480;
  if (858) { /* branch +55 */ }
  \u0001 = \u0001 + 106;
  if (514) { /* branch +61 */ }
  \u0001 = \u0001 + 390;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 53;
  if (952) { /* branch +33 */ }
  \u0001 = \u0001 - 208;
  if (744) { /* branch +29 */ }
  \u0001 = \u0001 - 744;
}
