// AVM1 Frame ActionScript (DoAction) — Tag #62 @ 0x13832
function onFrameTimeline():Void {
  if (963) { /* branch +33 */ }
  \u0001 = \u0001 - 369;
  if (904) { /* branch +34 */ }
  \u0001 = \u0001 - 793;
  if (710) { /* branch +117 */ }
  \u0001 = \u0001 - 466;
  if (627) { /* branch +33 */ }
  \u0001 = \u0001 - 7;
  if (295) { /* branch +29 */ }
  \u0001 = \u0001 + 609;
  if (594) { /* branch +61 */ }
  \u0001 = \u0001 - 84;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 371;
  if (139) { /* branch +28 */ }
  \u0001 = \u0001 + 488;
  if (510) { /* branch +33 */ }
  \u0001 = \u0001 - 371;
  if (348) { /* branch +39 */ }
  \u0001 = \u0001 - 53;
  if (229) { /* branch +55 */ }
  \u0001 = \u0001 + 119;
  if (244) { /* branch +33 */ }
  \u0001 = \u0001 + 78;
  if (388) { /* branch +61 */ }
  \u0001 = \u0001 + 322;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 466;
  if (111) { /* branch +29 */ }
  \u0001 = \u0001 + 21;
  if (132) { /* branch +29 */ }
  \u0001 = \u0001 + 256;
  if (877) { /* branch +28 */ }
  \u0001 = \u0001 - 529;
  if (322) { /* branch +29 */ }
  \u0001 = \u0001 - 322;
}
