// AVM1 DoInitAction (Sprite ID: 851) — Tag #448 @ 0x7FB5F
function onFrameTimeline():Void {
  if (724) { /* branch +33 */ }
  \u0001 = \u0001 - 515;
  if (754) { /* branch +48 */ }
  \u0001 = \u0001 - 309;
  if (452) { /* branch +61 */ }
  \u0001 = \u0001 + 232;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 660;
  if (876) { /* branch +34 */ }
  \u0001 = \u0001 - 77;
  if (975) { /* branch +33 */ }
  \u0001 = \u0001 - 970;
  if (802) { /* branch +29 */ }
  \u0001 = \u0001 + 74;
  if (633) { /* branch +450 */ }
  \u0001 = \u0001 + 342;
  if (987) { /* branch +29 */ }
  \u0001 = \u0001 + 1;
  if (445) { /* branch +39 */ }
  \u0001 = \u0001 + 357;
  if (209) { /* branch +61 */ }
  \u0001 = \u0001 + 17;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 678;
  if (5) { /* branch +29 */ }
  \u0001 = \u0001 - 5;
}
