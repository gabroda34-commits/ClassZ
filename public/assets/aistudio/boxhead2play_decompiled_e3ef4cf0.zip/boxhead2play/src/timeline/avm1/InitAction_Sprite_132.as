// AVM1 DoInitAction (Sprite ID: 132) — Tag #1321 @ 0x1B2586
function onFrameTimeline():Void {
  if (14) { /* branch +33 */ }
  \u0001 = \u0001 + 99;
  if (933) { /* branch +29 */ }
  \u0001 = \u0001 - 893;
  if (40) { /* branch +34 */ }
  \u0001 = \u0001 + 923;
  if (140) { /* branch +33 */ }
  \u0001 = \u0001 - 89;
  if (113) { /* branch +61 */ }
  \u0001 = \u0001 + 27;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 89;
  if (963) { /* branch +29 */ }
  \u0001 = \u0001 - 812;
  if (355) { /* branch +59 */ }
  \u0001 = \u0001 - 168;
  if (51) { /* branch +28 */ }
  \u0001 = \u0001 + 136;
  if (548) { /* branch +61 */ }
  \u0001 = \u0001 + 345;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 0;
  if (151) { /* branch +29 */ }
  \u0001 = \u0001 + 397;
  if (187) { /* branch +39 */ }
  \u0001 = \u0001 + 746;
  if (893) { /* branch +33 */ }
  \u0001 = \u0001 - 814;
  if (79) { /* branch +29 */ }
  \u0001 = \u0001 - 79;
}
