// AVM1 DoInitAction (Sprite ID: 835) — Tag #384 @ 0x6B301
function onFrameTimeline():Void {
  if (657) { /* branch +33 */ }
  \u0001 = \u0001 - 315;
  if (527) { /* branch +398 */ }
  \u0001 = \u0001 - 310;
  if (619) { /* branch +33 */ }
  \u0001 = \u0001 - 14;
  if (614) { /* branch +61 */ }
  \u0001 = \u0001 - 87;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 310;
  if (342) { /* branch +61 */ }
  \u0001 = \u0001 + 277;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 14;
  if (659) { /* branch +29 */ }
  \u0001 = \u0001 + 148;
  if (98) { /* branch +29 */ }
  \u0001 = \u0001 + 516;
  if (605) { /* branch +28 */ }
  \u0001 = \u0001 + 208;
  if (217) { /* branch +33 */ }
  \u0001 = \u0001 + 708;
  if (925) { /* branch +29 */ }
  \u0001 = \u0001 - 925;
}
