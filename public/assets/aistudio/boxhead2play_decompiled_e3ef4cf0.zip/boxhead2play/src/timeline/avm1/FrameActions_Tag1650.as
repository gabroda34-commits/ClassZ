// AVM1 Frame ActionScript (DoAction) — Tag #1650 @ 0x62CFA8
function onFrameTimeline():Void {
  stop();
}
