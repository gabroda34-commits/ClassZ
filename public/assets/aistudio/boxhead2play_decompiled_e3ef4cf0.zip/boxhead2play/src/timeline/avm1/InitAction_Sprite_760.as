// AVM1 DoInitAction (Sprite ID: 760) — Tag #84 @ 0x195DD
function onFrameTimeline():Void {
  if (124) { /* branch +33 */ }
  \u0001 = \u0001 + 744;
  if (508) { /* branch +29 */ }
  \u0001 = \u0001 - 140;
  if (392) { /* branch +39 */ }
  \u0001 = \u0001 - 27;
  if (544) { /* branch +34 */ }
  \u0001 = \u0001 - 36;
  if (617) { /* branch +55 */ }
  \u0001 = \u0001 - 225;
  if (368) { /* branch +29 */ }
  \u0001 = \u0001 + 250;
  if (868) { /* branch +61 */ }
  \u0001 = \u0001 + 69;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 85;
  if (365) { /* branch +29 */ }
  \u0001 = \u0001 + 179;
  if (937) { /* branch +33 */ }
  \u0001 = \u0001 - 85;
  if (529) { /* branch +769 */ }
  \u0001 = \u0001 - 152;
  if (618) { /* branch +61 */ }
  \u0001 = \u0001 - 89;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 152;
  if (852) { /* branch +28 */ }
  \u0001 = \u0001 - 460;
  if (377) { /* branch +33 */ }
  \u0001 = \u0001 + 612;
  if (989) { /* branch +29 */ }
  \u0001 = \u0001 - 989;
}
