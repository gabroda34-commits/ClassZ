// AVM1 Frame ActionScript (DoAction) — Tag #539 @ 0x98F35
function onFrameTimeline():Void {
  // Stack operations disassembled in P-Code pane
}
