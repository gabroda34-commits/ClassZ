// AVM1 DoInitAction (Sprite ID: 871) — Tag #528 @ 0x98B45
function onFrameTimeline():Void {
  if (243) { /* branch +33 */ }
  \u0001 = \u0001 + 634;
  if (188) { /* branch +133 */ }
  \u0001 = \u0001 + 466;
  if (674) { /* branch +29 */ }
  \u0001 = \u0001 - 469;
  if (205) { /* branch +61 */ }
  \u0001 = \u0001 - 17;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 466;
  if (877) { /* branch +61 */ }
  \u0001 = \u0001 - 469;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 15;
  if (394) { /* branch +34 */ }
  \u0001 = \u0001 - 122;
  if (654) { /* branch +33 */ }
  \u0001 = \u0001 - 106;
  if (272) { /* branch +29 */ }
  \u0001 = \u0001 + 402;
  if (807) { /* branch +29 */ }
  \u0001 = \u0001 - 413;
  if (393) { /* branch +28 */ }
  \u0001 = \u0001 + 591;
  if (408) { /* branch +33 */ }
  \u0001 = \u0001 - 15;
  if (819) { /* branch +43 */ }
  \u0001 = \u0001 + 165;
  if (984) { /* branch +39 */ }
  \u0001 = \u0001 - 177;
  if (548) { /* branch +29 */ }
  \u0001 = \u0001 - 548;
}
