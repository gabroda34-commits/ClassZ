// AVM1 DoInitAction (Sprite ID: 848) — Tag #436 @ 0x7B1C7
function onFrameTimeline():Void {
  if (593) { /* branch +33 */ }
  \u0001 = \u0001 + 182;
  if (441) { /* branch +29 */ }
  \u0001 = \u0001 + 302;
  if (114) { /* branch +29 */ }
  \u0001 = \u0001 + 654;
  if (675) { /* branch +56 */ }
  \u0001 = \u0001 - 325;
  if (489) { /* branch +975 */ }
  \u0001 = \u0001 + 406;
  if (102) { /* branch +28 */ }
  \u0001 = \u0001 + 248;
  if (212) { /* branch +33 */ }
  \u0001 = \u0001 - 110;
  if (775) { /* branch +61 */ }
  \u0001 = \u0001 - 563;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 110;
  if (350) { /* branch +39 */ }
  \u0001 = \u0001 - 236;
  if (768) { /* branch +34 */ }
  \u0001 = \u0001 + 52;
  if (820) { /* branch +29 */ }
  \u0001 = \u0001 - 379;
  if (743) { /* branch +61 */ }
  \u0001 = \u0001 - 254;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 406;
  if (895) { /* branch +33 */ }
  \u0001 = \u0001 - 889;
  if (6) { /* branch +29 */ }
  \u0001 = \u0001 - 6;
}
