// AVM1 DoInitAction (Sprite ID: 195) — Tag #1331 @ 0x1B45CE
function onFrameTimeline():Void {
  if (331) { /* branch +33 */ }
  \u0001 = \u0001 + 387;
  if (299) { /* branch +33 */ }
  \u0001 = \u0001 + 133;
  if (682) { /* branch +29 */ }
  \u0001 = \u0001 - 62;
  if (165) { /* branch +33 */ }
  \u0001 = \u0001 + 810;
  if (718) { /* branch +61 */ }
  \u0001 = \u0001 - 553;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 810;
  if (975) { /* branch +28 */ }
  \u0001 = \u0001 - 592;
  if (748) { /* branch +29 */ }
  \u0001 = \u0001 - 357;
  if (168) { /* branch +43 */ }
  \u0001 = \u0001 + 215;
  if (383) { /* branch +39 */ }
  \u0001 = \u0001 + 365;
  if (391) { /* branch +34 */ }
  \u0001 = \u0001 + 411;
  if (802) { /* branch +29 */ }
  \u0001 = \u0001 - 120;
  if (620) { /* branch +61 */ }
  \u0001 = \u0001 - 321;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 0;
  if (432) { /* branch +29 */ }
  \u0001 = \u0001 - 432;
}
