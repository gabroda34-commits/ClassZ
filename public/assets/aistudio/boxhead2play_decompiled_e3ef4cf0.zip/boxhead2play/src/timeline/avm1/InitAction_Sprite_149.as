// AVM1 DoInitAction (Sprite ID: 149) — Tag #1325 @ 0x1B32D8
function onFrameTimeline():Void {
  if (288) { /* branch +33 */ }
  \u0001 = \u0001 + 234;
  if (98) { /* branch +29 */ }
  \u0001 = \u0001 + 737;
  if (835) { /* branch +61 */ }
  \u0001 = \u0001 - 226;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 0;
  if (296) { /* branch +29 */ }
  \u0001 = \u0001 - 18;
  if (946) { /* branch +54 */ }
  \u0001 = \u0001 - 504;
  if (522) { /* branch +61 */ }
  \u0001 = \u0001 - 413;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 85;
  if (109) { /* branch +33 */ }
  \u0001 = \u0001 + 85;
  if (278) { /* branch +34 */ }
  \u0001 = \u0001 - 160;
  if (609) { /* branch +33 */ }
  \u0001 = \u0001 + 57;
  if (118) { /* branch +29 */ }
  \u0001 = \u0001 - 20;
  if (194) { /* branch +28 */ }
  \u0001 = \u0001 + 248;
  if (666) { /* branch +29 */ }
  \u0001 = \u0001 - 666;
}
