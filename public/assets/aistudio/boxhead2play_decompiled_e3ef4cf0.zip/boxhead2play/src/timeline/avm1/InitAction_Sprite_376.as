// AVM1 DoInitAction (Sprite ID: 376) — Tag #1339 @ 0x1B5EC7
function onFrameTimeline():Void {
  if (125) { /* branch +33 */ }
  \u0001 = \u0001 + 143;
  if (568) { /* branch +29 */ }
  \u0001 = \u0001 - 178;
  if (268) { /* branch +61 */ }
  \u0001 = \u0001 + 81;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 389;
  if (86) { /* branch +39 */ }
  \u0001 = \u0001 + 482;
  if (349) { /* branch +33 */ }
  \u0001 = \u0001 + 389;
  if (738) { /* branch +28 */ }
  \u0001 = \u0001 - 652;
  if (113) { /* branch +29 */ }
  \u0001 = \u0001 + 793;
  if (362) { /* branch +33 */ }
  \u0001 = \u0001 + 435;
  if (555) { /* branch +57 */ }
  \u0001 = \u0001 - 469;
  if (390) { /* branch +34 */ }
  \u0001 = \u0001 - 277;
  if (906) { /* branch +29 */ }
  \u0001 = \u0001 - 425;
  if (481) { /* branch +61 */ }
  \u0001 = \u0001 - 119;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 0;
  if (797) { /* branch +29 */ }
  \u0001 = \u0001 - 797;
}
