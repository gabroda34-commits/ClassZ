// AVM1 DoInitAction (Sprite ID: 846) — Tag #428 @ 0x79C65
function onFrameTimeline():Void {
  if (38) { /* branch +33 */ }
  \u0001 = \u0001 + 350;
  if (756) { /* branch +29 */ }
  \u0001 = \u0001 + 183;
  if (632) { /* branch +33 */ }
  \u0001 = \u0001 - 598;
  if (739) { /* branch +433 */ }
  \u0001 = \u0001 - 420;
  if (880) { /* branch +50 */ }
  \u0001 = \u0001 + 100;
  if (939) { /* branch +61 */ }
  \u0001 = \u0001 - 200;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 420;
  if (643) { /* branch +29 */ }
  \u0001 = \u0001 + 113;
  if (801) { /* branch +34 */ }
  \u0001 = \u0001 - 158;
  if (34) { /* branch +28 */ }
  \u0001 = \u0001 + 946;
  if (980) { /* branch +39 */ }
  \u0001 = \u0001 - 286;
  if (694) { /* branch +29 */ }
  \u0001 = \u0001 + 107;
  if (319) { /* branch +33 */ }
  \u0001 = \u0001 - 95;
  if (388) { /* branch +61 */ }
  \u0001 = \u0001 + 244;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 598;
  if (224) { /* branch +29 */ }
  \u0001 = \u0001 - 224;
}
