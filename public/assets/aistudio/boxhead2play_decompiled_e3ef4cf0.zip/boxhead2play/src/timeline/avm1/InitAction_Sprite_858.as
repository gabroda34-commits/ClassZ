// AVM1 DoInitAction (Sprite ID: 858) — Tag #476 @ 0x8D6F3
function onFrameTimeline():Void {
  if (723) { /* branch +33 */ }
  \u0001 = \u0001 - 260;
  if (608) { /* branch +28 */ }
  \u0001 = \u0001 + 124;
  if (15) { /* branch +61 */ }
  \u0001 = \u0001 + 25;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 611;
  if (157) { /* branch +29 */ }
  \u0001 = \u0001 + 252;
  if (464) { /* branch +33 */ }
  \u0001 = \u0001 + 49;
  if (440) { /* branch +61 */ }
  \u0001 = \u0001 - 293;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 461;
  if (804) { /* branch +44 */ }
  \u0001 = \u0001 - 72;
  if (463) { /* branch +61 */ }
  \u0001 = \u0001 + 486;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 207;
  if (742) { /* branch +28 */ }
  \u0001 = \u0001 - 358;
  if (760) { /* branch +126 */ }
  \u0001 = \u0001 - 296;
  if (513) { /* branch +29 */ }
  \u0001 = \u0001 - 513;
}
