// AVM1 DoInitAction (Sprite ID: 798) — Tag #236 @ 0x4CA6E
function onFrameTimeline():Void {
  if (891) { /* branch +33 */ }
  \u0001 = \u0001 - 511;
  if (606) { /* branch +33 */ }
  \u0001 = \u0001 - 540;
  if (746) { /* branch +29 */ }
  \u0001 = \u0001 - 102;
  if (380) { /* branch +61 */ }
  \u0001 = \u0001 + 57;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 56;
  if (381) { /* branch +28 */ }
  \u0001 = \u0001 + 49;
  if (260) { /* branch +39 */ }
  \u0001 = \u0001 + 305;
  if (940) { /* branch +216 */ }
  \u0001 = \u0001 - 334;
  if (307) { /* branch +61 */ }
  \u0001 = \u0001 - 179;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 662;
  if (437) { /* branch +33 */ }
  \u0001 = \u0001 - 56;
  if (900) { /* branch +61 */ }
  \u0001 = \u0001 + 31;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 417;
  if (514) { /* branch +28 */ }
  \u0001 = \u0001 - 254;
  if (66) { /* branch +29 */ }
  \u0001 = \u0001 - 66;
}
