// AVM1 DoInitAction (Sprite ID: 74) — Tag #1345 @ 0x1B6F0E
function onFrameTimeline():Void {
  if (368) { /* branch +33 */ }
  \u0001 = \u0001 - 217;
  if (151) { /* branch +61 */ }
  \u0001 = \u0001 + 593;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 253;
  if (354) { /* branch +47 */ }
  \u0001 = \u0001 + 224;
  if (949) { /* branch +33 */ }
  \u0001 = \u0001 - 622;
  if (744) { /* branch +33 */ }
  \u0001 = \u0001 - 253;
  if (491) { /* branch +28 */ }
  \u0001 = \u0001 + 87;
  if (578) { /* branch +39 */ }
  \u0001 = \u0001 + 419;
  if (703) { /* branch +29 */ }
  \u0001 = \u0001 - 111;
  if (490) { /* branch +34 */ }
  \u0001 = \u0001 + 213;
  if (997) { /* branch +29 */ }
  \u0001 = \u0001 - 507;
  if (592) { /* branch +29 */ }
  \u0001 = \u0001 + 260;
  if (852) { /* branch +61 */ }
  \u0001 = \u0001 + 97;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 0;
  if (327) { /* branch +29 */ }
  \u0001 = \u0001 - 327;
}
