// AVM1 Frame ActionScript (DoAction) — Tag #1618 @ 0x1BE9FF
function onFrameTimeline():Void {
  if (366) { /* branch +33 */ }
  \u0001 = \u0001 + 228;
  if (273) { /* branch +29 */ }
  \u0001 = \u0001 - 153;
  if (722) { /* branch +48 */ }
  \u0001 = \u0001 - 73;
  if (865) { /* branch +29 */ }
  \u0001 = \u0001 - 774;
  if (649) { /* branch +39 */ }
  \u0001 = \u0001 - 376;
  if (91) { /* branch +61 */ }
  \u0001 = \u0001 + 677;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 308;
  if (768) { /* branch +129 */ }
  \u0001 = \u0001 - 308;
  if (460) { /* branch +33 */ }
  \u0001 = \u0001 + 232;
  if (55) { /* branch +29 */ }
  \u0001 = \u0001 + 810;
  if (692) { /* branch +29 */ }
  \u0001 = \u0001 - 692;
}
