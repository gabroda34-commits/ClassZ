// AVM1 DoInitAction (Sprite ID: 775) — Tag #144 @ 0x33ED6
function onFrameTimeline():Void {
  if (590) { /* branch +33 */ }
  \u0001 = \u0001 - 61;
  if (120) { /* branch +28 */ }
  \u0001 = \u0001 + 578;
  if (530) { /* branch +29 */ }
  \u0001 = \u0001 - 149;
  if (272) { /* branch +33 */ }
  \u0001 = \u0001 - 152;
  if (430) { /* branch +1668 */ }
  \u0001 = \u0001 - 258;
  if (690) { /* branch +48 */ }
  \u0001 = \u0001 + 8;
  if (529) { /* branch +61 */ }
  \u0001 = \u0001 - 257;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 152;
  if (148) { /* branch +29 */ }
  \u0001 = \u0001 + 382;
  if (698) { /* branch +39 */ }
  \u0001 = \u0001 - 288;
  if (410) { /* branch +29 */ }
  \u0001 = \u0001 - 379;
  if (172) { /* branch +33 */ }
  \u0001 = \u0001 + 213;
  if (31) { /* branch +34 */ }
  \u0001 = \u0001 + 117;
  if (381) { /* branch +61 */ }
  \u0001 = \u0001 + 49;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 258;
  if (385) { /* branch +29 */ }
  \u0001 = \u0001 - 385;
}
