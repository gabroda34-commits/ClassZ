// AVM1 DoInitAction (Sprite ID: 864) — Tag #500 @ 0x90E0F
function onFrameTimeline():Void {
  if (127) { /* branch +33 */ }
  \u0001 = \u0001 + 1;
  if (967) { /* branch +61 */ }
  \u0001 = \u0001 - 643;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 332;
  if (881) { /* branch +33 */ }
  \u0001 = \u0001 + 77;
  if (891) { /* branch +33 */ }
  \u0001 = \u0001 + 73;
  if (520) { /* branch +29 */ }
  \u0001 = \u0001 - 254;
  if (798) { /* branch +61 */ }
  \u0001 = \u0001 - 344;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 437;
  if (312) { /* branch +61 */ }
  \u0001 = \u0001 + 569;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 77;
  if (617) { /* branch +33 */ }
  \u0001 = \u0001 - 488;
  if (128) { /* branch +61 */ }
  \u0001 = \u0001 + 489;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 488;
  if (454) { /* branch +123 */ }
  \u0001 = \u0001 + 437;
  if (487) { /* branch +39 */ }
  \u0001 = \u0001 - 313;
  if (964) { /* branch +29 */ }
  \u0001 = \u0001 - 964;
}
