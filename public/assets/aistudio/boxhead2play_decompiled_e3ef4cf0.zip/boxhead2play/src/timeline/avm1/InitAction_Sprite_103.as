// AVM1 DoInitAction (Sprite ID: 103) — Tag #1311 @ 0x1B02E0
function onFrameTimeline():Void {
  if (532) { /* branch +33 */ }
  \u0001 = \u0001 + 368;
  if (900) { /* branch +61 */ }
  \u0001 = \u0001 - 682;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 66;
  if (781) { /* branch +29 */ }
  \u0001 = \u0001 - 2;
  if (218) { /* branch +33 */ }
  \u0001 = \u0001 - 66;
  if (88) { /* branch +39 */ }
  \u0001 = \u0001 + 693;
  if (152) { /* branch +28 */ }
  \u0001 = \u0001 - 64;
  if (590) { /* branch +51 */ }
  \u0001 = \u0001 - 502;
  if (279) { /* branch +29 */ }
  \u0001 = \u0001 + 485;
  if (779) { /* branch +34 */ }
  \u0001 = \u0001 - 500;
  if (764) { /* branch +29 */ }
  \u0001 = \u0001 - 164;
  if (600) { /* branch +61 */ }
  \u0001 = \u0001 - 138;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 0;
  if (462) { /* branch +33 */ }
  \u0001 = \u0001 + 160;
  if (622) { /* branch +29 */ }
  \u0001 = \u0001 - 622;
}
