// AVM1 DoInitAction (Sprite ID: 806) — Tag #268 @ 0x529D2
function onFrameTimeline():Void {
  if (147) { /* branch +33 */ }
  \u0001 = \u0001 + 138;
  if (123) { /* branch +810 */ }
  \u0001 = \u0001 + 619;
  if (2) { /* branch +28 */ }
  \u0001 = \u0001 + 608;
  if (285) { /* branch +61 */ }
  \u0001 = \u0001 + 17;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 37;
  if (220) { /* branch +61 */ }
  \u0001 = \u0001 - 97;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 619;
  if (543) { /* branch +29 */ }
  \u0001 = \u0001 - 323;
  if (568) { /* branch +29 */ }
  \u0001 = \u0001 - 350;
  if (742) { /* branch +33 */ }
  \u0001 = \u0001 + 242;
  if (862) { /* branch +33 */ }
  \u0001 = \u0001 - 860;
  if (128) { /* branch +33 */ }
  \u0001 = \u0001 + 460;
  if (588) { /* branch +61 */ }
  \u0001 = \u0001 + 274;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 - 860;
  if (347) { /* branch +29 */ }
  \u0001 = \u0001 + 196;
  if (984) { /* branch +29 */ }
  \u0001 = \u0001 - 984;
}
