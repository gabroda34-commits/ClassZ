// AVM1 DoInitAction (Sprite ID: 94) — Tag #1307 @ 0x1AF878
function onFrameTimeline():Void {
  if (357) { /* branch +33 */ }
  \u0001 = \u0001 - 141;
  if (620) { /* branch +45 */ }
  \u0001 = \u0001 + 98;
  if (742) { /* branch +61 */ }
  \u0001 = \u0001 - 49;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 223;
  if (496) { /* branch +61 */ }
  \u0001 = \u0001 + 133;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 0;
  if (693) { /* branch +33 */ }
  \u0001 = \u0001 + 223;
  if (216) { /* branch +61 */ }
  \u0001 = \u0001 + 575;
  if (\u0001) { /* branch +5 */ }
  \u0001 = \u0001 + 123;
  if (916) { /* branch +28 */ }
  \u0001 = \u0001 - 198;
  if (74) { /* branch +33 */ }
  \u0001 = \u0001 + 668;
  if (286) { /* branch +29 */ }
  \u0001 = \u0001 + 210;
  if (454) { /* branch +29 */ }
  \u0001 = \u0001 - 168;
  if (791) { /* branch +33 */ }
  \u0001 = \u0001 + 123;
  if (629) { /* branch +33 */ }
  \u0001 = \u0001 - 519;
  if (110) { /* branch +29 */ }
  \u0001 = \u0001 - 110;
}
